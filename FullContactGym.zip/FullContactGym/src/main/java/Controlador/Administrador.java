/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author spala
 */

public class Administrador extends Persona {

    public Administrador(String id, String clave, String rol, String nombre, String correo, String fechaNacimiento, String genero, String estado) {
        super(id, clave, rol, nombre, correo, fechaNacimiento, genero, estado);
    }
}